Exceptions
----------

.. module:: easysnmp

.. autoclass:: EasySNMPError
.. autoclass:: EasySNMPConnectionError
.. autoclass:: EasySNMPTimeoutError
.. autoclass:: EasySNMPUnknownObjectIDError
.. autoclass:: EasySNMPNoSuchObjectError
.. autoclass:: EasySNMPNoSuchInstanceError
.. autoclass:: EasySNMPUndeterminedTypeError
